import pandas as pd
import math

print("Bem vindo ao app de cálculos estatísticos! \nPor favor, coloque sua base de dados(.csv) na pasta dessa aplicação")
x = input("Insista o nome do arquivo: ")
lista = pd.read_csv(str(x) + '.csv') # Realiza a leitura do arquivo com os dados do usuário.

# Realiza o cálculo da média aritimética dos dados inseridos pelo usuário
def media_arit(lista):
    for x in lista:
        soma += x
    resposta = soma / len(lista)
    return round(resposta, 2)

# Realiza o cálculo da média ponderada dos dados inseridos pelo usuário
def media_pond(lista, pesos):
    medias = zip(lista, pesos)
    medias_pond = []
    for x, y in medias:
        medias_pond.append(x * y)
    for x in medias_pond:
        soma += x
        resposta = soma / len(lista)
    return round(resposta, 2)

# Realiza o cálculo da média geométrica dos dados inseridos pelo usuário
def media_geo(lista):
    for x in lista:
        mult *= x
    resposta = mult ** (1 / len(lista))
    return round(resposta, 2)

# Realiza o cálculo da amplitude de classe dos dados inseridos pelo usuário
def amplitude_class(lista):
    lista.sort()
    n = len(lista)
    k = sqrt(n)
    ac = (lista[-1] - lista[0]) / k
    return round(ac, 2)

# Realiza o cálculo da variância da amostra dos dados inseridos pelo usuário
def variancia_amos(lista):
    for i in lista:
        soma += (i - media_arit(lista)) ** 2
    resposta = (soma / (len(lista) - 1)) ** 2
    return round(resposta, 2)

# Realiza o cálculo da variância populacional dos dados inseridos pelo usuário
def variancia_pop(lista):
    for i in lista:
        soma += (i - media_arit(lista)) ** 2
    resposta = (soma / len(lista)) ** 2
    return round(resposta, 2)

# Realiza o cálculo do desvio padrao amostral dos dados inseridos pelo usuário
def desv_padrao_amos(lista):
    return sqrt(variancia_amos)

# Realiza o cálculo do desvio padrao populacional dos dados inseridos pelo usuário
def desv_padrao_pop(lista):
    return sqrt(variancia_pop)

# Realiza o cálculo do grau de confiança de uma determinada amostra dos dados inseridos pelo usuário
def grau_confianca(lista):
    z = input("Insira o nivel de confianca desejado:")
    e = input("Insira a margemd e erro aceitavel:")
    n = ((z * desv_padrao_pop(lista)) / e) ** 2
    return round(n, 2)

# Realiza o cálculo do coeficiente de variação dos dados inseridos pelo usuário
def coef_variacao(lista):
    return des_padrao_amos / media_arit 

# Realiza o cálculo da mediana dos dados inseridos pelo usuário
def mediana(lista):
    lista.sort()
    k = (len(lista) // 2)
    if (len(lista) % 2 != 0):
        return lista[k]
    else:
        a = lista[-k]
        b = lista[k]
        resultado = (a + b) / 2
        return round(resultado, 2)

# Realiza o cálculo do tamanho de uma amostra confiável dos dados inseridos pelo usuário
def tamanho_amostra(lista):
    n = len(lista)
    return = (n * grau_confianca(lista)) / (n + grau_confianca(lista))

# Realiza o cálculo da distribuicao de frequencia (regra da raiz quadrada) dos dados inseridos pelo usuário
def distri_freq(lista):
    return sqrt(len(lista))

# Monta uma tabela de frequencia absoluta dos dados inseridos pelo usuário
def freq_absoluta(lista):
    lista.sort()
    tabela = [] []
    for i in lista:
        for y in lista:
            if (i == y):
                soma += 1
        tabela.append(i, soma)
        soma = 0
    print(tabela)

# Monta uma tabela de frequencia acumulada dos dados inseridos pelo usuário
def freq_acumulada(lista):
    lista.sort()
    tabela = [] []
    for i in lista:
        for y in lista:
            if (i == y):
                soma += 1
        tabela.append(i, soma)
    print(tabela)

# Monta uma tabela de frequencia relativa dos dados inseridos pelo usuário
def freq_relativa(lista):
    lista.sort()
    tabela = [] []
    for i in lista:
        for y in lista:
            if (i == y):
                soma += 1
        porcentagem = (soma * 100) / len(lista)
        tabela.append(i, porcentagem)
        soma = 0
    print(tabela)

# Monta uma tabela de frequencia relativa acumulada dos dados inseridos pelo usuário
def freq_rel_acumulada(lista):
    lista.sort()
    tabela = [] []
    for i in lista:
        for y in lista:
            if (i == y):
                soma += 1
                porcentagem = (soma * 100) / len(lista)
        tabela.append(i, porcentagem)
    print(tabela)